#!/usr/bin/env python2
# chat_client.py

import sys, socket, select
from threading import *
from colorama import Fore, Back, Style
import datetime
import signal
import os
now = datetime.datetime.now()

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def send_msg(s):
    while True:
        msg = sys.stdin.readline()
        s.send(msg.encode())
        sys.stdout.write('------------------\n' + f'[ {username}' + " ]~$ "); sys.stdout.flush()
        
def recv_msg(sock):
    while True:
        data = sock.recv(4096)
        if not data :
            print ('\nDisconnected from chat server')
            sys.exit()
        else :
            #print data
            sys.stdout.write(data.decode())
            sys.stdout.write('------------------\n' + f'[ {username}' + " ]~$ "); sys.stdout.flush()

def signal_handler(signal, frame):
    print("\n_____________")
    print(Fore.LIGHTRED_EX + "ꜰᴏʀᴄᴇ ᴄʟᴏꜱᴇ!")
    print("")
    os._exit(1)

def chat_client():
    if(len(sys.argv) < 3) :
        print("\n_____________")
        print (Fore.LIGHTRED_EX + '𝐄𝐱𝐚𝐦𝐩𝐥𝐞 : 𝐩𝐲𝐭𝐡𝐨𝐧𝟑 [𝐟𝐢𝐥𝐞.𝐩𝐲] 𝐥𝐨𝐜𝐚𝐥𝐡𝐨𝐬𝐭 𝟗𝟎𝟎𝟏')
        sys.exit()

    host = sys.argv[1]
    port = int(sys.argv[2])

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # connect to remote host
    try :
        s.connect((host, port))
        print(Fore.LIGHTMAGENTA_EX + """    
  
   𝓬𝓻𝓮𝓪𝓽𝓮𝓭 𝓫𝔂 ~$ 𝖆𝖓𝖔𝖓𝖗𝖊
                                         """)
        print(Fore.LIGHTCYAN_EX + '------------------------------------------')
        global username 
        username = input('Enter Your Username ~$ ')
        print(Fore.LIGHTBLUE_EX + '------------------------------------------')
        s.send(username.encode())

    except KeyboardInterrupt:
        print("\n_____________")
        print(Fore.LIGHTRED_EX + "ꜰᴏʀᴄᴇ ᴄʟᴏꜱᴇ!")
        print("")
        sys.exit()
    except:
        print("\n__________________________")
        print (Fore.LIGHTRED_EX + "ᴄᴀɴ'ᴛ ʀᴜɴ ᴛʜᴇ ᴀᴘᴘʟɪᴄᴀᴛɪᴏɴ")
        sys.exit()
    
    print('Connected! You can start sending messages!')
    print("")
    print('You Connected On',now.strftime('[%H:%M:%S on %A]')) 
    print("------------------------------------------")

    sys.stdout.write(Fore.LIGHTYELLOW_EX + f'[ { username }' + " ]~$ " ); sys.stdout.flush()
            
    Thread(target=send_msg, args=(s,)).start()
    Thread(target=recv_msg, args=(s,)).start()

    signal.signal(signal.SIGINT, signal_handler)
    forever = Event()
    forever.wait()
    
if __name__ == "__main__":
    sys.exit(chat_client())


